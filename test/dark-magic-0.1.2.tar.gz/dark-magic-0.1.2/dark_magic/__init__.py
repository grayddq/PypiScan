"""dark-magic - This package includes some useful optimizations"""

__version__ = '0.1.0'
__author__ = 'Joel Rogan <louis@kragniz.eu>'
__all__ = []
